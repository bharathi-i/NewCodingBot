package com.example.Junta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JuntaApplication {

	public static void main(String[] args) {
		SpringApplication.run(JuntaApplication.class, args);
	}

}
