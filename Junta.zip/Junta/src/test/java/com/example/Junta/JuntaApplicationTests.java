package com.example.Junta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JuntaApplicationTests {

	@Test
	void contextLoads() {
	}

}
